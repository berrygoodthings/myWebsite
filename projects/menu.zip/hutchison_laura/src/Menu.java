import java.util.Scanner;

/*@author Laura Hutchison
 * Oct 2018
 * @version 1.0
 */

public class Menu {
	
	 /*Declaring choice class
	 * @param mainMenuChoice - class used to access choices
	 * @param userChoice used to acces main menu options
	 */
	//Choice mainMenuChoice = new Choice();
	int userChoice;
	
	public static void main(String[] args) {

		Scanner tempInfo = new Scanner(System.in);
		//@param newMenu creates instance of menu to display options to user
		Menu newMenu = new Menu();
		newMenu.processUserChoices(tempInfo);
	}
	
	public static void displayMenu() {
		System.out.println("This is the base menu.");
		System.out.println("Please choose from the following options.");
		System.out.println("1: Categorise student grade");
		System.out.println("2. Upper and lower parameter program");
		System.out.println("3. Maximum and minimum number program");
		System.out.println("4. Enhanced student grade categorisation");
		System.out.println("5. Exit menu");
	}
	
	
	public void processUserChoices(Scanner tempInfo) {
		
		Menu.displayMenu();
		
		/*Declaring and starting menu choice selection
		 * @param tempInfo will scan user input to feed into userChoice
		 * @param userChoice int used to select from menu
		 */
		
		int userChoice = tempInfo.nextInt();
		
		 if(userChoice == 1) {
			 
			//@param gradeHolder is to hold student's garde
			//@param grade is used to categorise student's grade
			Scanner gradeHolder = new Scanner(System.in);
				
			//we will grab the grade
			System.out.println("What is the student's grade?");
			int grade = gradeHolder.nextInt();
				
			Choice.gradeGiver(grade);
			Menu.displayMenu();
		}
		 
		if(userChoice == 2) {
			
			Scanner grabNumber = new Scanner(System.in);
			int lowerBound = 0;
			int upperBound = 0;
			
			System.out.println("Please enter the lower bound number.");
			
			String input = grabNumber.nextLine();
			
			try {

				lowerBound = Integer.parseInt(input);
			} catch (NumberFormatException e) {
			    System.out.println("Input is not a valid integer");
			}
			
			System.out.println("Please enter the upper bound number.");
			
			input = grabNumber.nextLine();
			
			try {

				upperBound = Integer.parseInt(input);
			} catch (NumberFormatException e) {
			    System.out.println("Input is not a valid integer");
		
			}
			
			Choice.rangeTable(lowerBound, upperBound);			
			Menu.displayMenu();
		}
		
		if(userChoice == 3) {
			Choice.maxMin();
			Menu.displayMenu();
		}
		
		if(userChoice == 4) {
			Choice.enhancedStudentGrade();
			Menu.displayMenu();
		}
		
		if(userChoice == 5) {
			Choice.exit();
		}
		
		if(userChoice >= 6 || userChoice <= 0) {
			System.out.println("Please enter a valid menu option.");
			
		}
		
		do{
			processUserChoices(tempInfo);
		}
		while(userChoice != 5);
	}
	
}

