import java.text.DecimalFormat;
import java.util.Scanner;

/*This class for de choices
 * @author Laura Hutchison
 * @version 1.0
 * Oct 2018
 */

public class Choice {

	
	
	public static void gradeGiver(int grade) {
		
		//Categorise grades from letters A to F based on grade percentage.
		if(grade >= 70 && grade <= 100) {
			System.out.println("The student has an A.");
		}
		if(grade <= 69 && grade > 59) {
			System.out.println("The student has a B.");
		}
		if(grade <= 59 && grade > 49) {
			System.out.println("The student has a C.");
		}
		if(grade <= 49 && grade > 39) {
			System.out.println("The student has a D.");
		}
		if(grade <= 39 && grade >= 0) {
			System.out.println("The student has an F.");
		}
	}
	
	public static void rangeTable(int lowerBound, int upperBound) {
		
		//@param grabNumber will grab number input and then give to lower and upper bound
		//@param lowerBound is lower bound number
		//@param upperBound is upper bound number
		//@param squareRoot is variable used to hold square root
		int boundCounter;
		int squareNumber;
		int cubeNumber;
		double squareRoot;
		
		boundCounter = upperBound;
		
		//enter the upper and lower parameters
		if(lowerBound > upperBound) {
			System.out.println("Please enter a proper lower and upper bound.");
		}

		if(lowerBound < upperBound) {
			
			System.out.println("Value\tSquare\tCube\tSquare Root");
			do {
				
				squareNumber = boundCounter * boundCounter;
				cubeNumber = boundCounter * 2;
				squareRoot = Math.sqrt(boundCounter);
				DecimalFormat sqRt = new DecimalFormat("##.00");
				
				System.out.println(boundCounter +"\t" + squareNumber + "\t" + cubeNumber + "\t" + sqRt.format(squareRoot));
				
				boundCounter--;
			}
			while(boundCounter >= lowerBound);
		}
	}
	
	public static void maxMin() {
		System.out.println("This option accepts numbers until -1 is entered.");
		System.out.println("This will calculate the total value, max, and min numbers");
		
		/*
		 * @param input is a scanner to take number data for choice 3 from user
		 * @param numberNumberWhat is a counter for the amount of numbers entered
		 * @param maxNumber is the maximum value number entered
		 * @param minNumber is minimum value number entered
		 * @param numberTotal is sum of all entered numbers
		 * @param numberAvg is the average value of numbers
		 * @param numberInput is the int value of number input
		 */
		Scanner input = new Scanner(System.in);
		int numberNumberWhat = 0;
		int maxNumber = 0;
		int minNumber = 0;
		int numberTotal = 0;
		double numberAvg = 0;
		
		//Grab input from user for max min
		System.out.println("Enter a number 0 or over - press -1 to exit");
		int numberInput = input.nextInt();
		 
		maxNumber = numberInput;
		minNumber = numberInput;
		numberNumberWhat++;
		numberAvg = 1.0 * numberInput;
		numberTotal = numberInput;
		 
		System.out.println("Your maximum number is " + maxNumber);
		System.out.println("Your minimum number is " + minNumber);
		System.out.println("Your number average is " + numberAvg);
		System.out.println("Your numbers' sum is " + numberTotal);
		 
		 do {
				 System.out.println("Enter a number 0 or over - press -1 to exit");
				 numberInput = input.nextInt();
				 
				 if (numberInput == -1) {
					 break;
					 
				 }
				 
				 if(numberInput >= maxNumber) {
					 maxNumber = numberInput;
				 }
				 if(numberInput <= minNumber) {
					 minNumber = numberInput;
				 }
				 
				 numberNumberWhat++;
				 
				 numberTotal = numberTotal + numberInput;
				 numberAvg = (double) numberTotal / numberNumberWhat;
				 
				 System.out.println("Your maximum number is " + maxNumber);
				 System.out.println("Your minimum number is " + minNumber);
				 System.out.println("Your number average is " + numberAvg);
				 System.out.println("Your numbers' sum is " + numberTotal);
				 
				 	 
		 }
		
		 while(numberInput >= 0 || numberInput != -1);
		 
	}
	
	public static void enhancedStudentGrade() {
		
		System.out.println("Please enter the student's grade in percentage. Enter -1 to exit.");
		
		//@param gradeHolder is to hold student's gradede
		//@param wrongCounter holds how many times wrong grade has been entered - at 3, we exit this option
		//@param grade is used to categorise student's grade
		Scanner gradeHolder = new Scanner(System.in);
		int wrongCounter = 0;
		int grade = 0;
		
		//we will grab the grade
		do{System.out.println("What is the student's grade?");
			grade = gradeHolder.nextInt();
			
			//if grade wrong, +1 more try until 3 wrong - parameters >= 101 and <= -2 as -1 is exit interger
			if(grade >=101) {
				wrongCounter++;
				System.out.println("You have entered a grade outside the grading scale. Please try again.");
				System.out.println("You have entered a wrong grade " + wrongCounter + "times.");
			}
			
			if(grade <= -2) {
				wrongCounter++;
				System.out.println("You have entered a grade outside the grading scale. Please try again.");
				System.out.println("You have entered a wrong grade " + wrongCounter + " times.");
			}
			
			if(wrongCounter == 3) {
				System.out.println("You have entered a wrong grade too many times.");
				break;
			}
			
			//if grade = -1 break loop 
			if(grade == -1) {
				break;
			}
			
			//@param goAgain allows user to select if they want option 4 to loop or not
			if(grade <= 100 && grade >= 0) {
			int goAgain;
			Choice.gradeGiver(grade);
			System.out.println("Would you like to enter another grade? Press 1 to exit. Enter any other number to continue.");
			goAgain = gradeHolder.nextInt();
			
			if(goAgain == 1) {
			break;
			}
			
		}
	}
		while(wrongCounter > 3 || grade != -1);
		
	}
	
	public static void exit() {
		System.out.println("Thank you for using this program. Goodbye.");
		System.exit(0);
	}
}
